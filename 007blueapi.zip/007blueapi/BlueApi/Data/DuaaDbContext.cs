﻿using BlueApi.Model;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace BlueApi.Data
{
    public class DuaaDbContext :DbContext
    {
        public DuaaDbContext(DbContextOptions<DuaaDbContext> options) : base(options)
        {

        }
        public DbSet<Duaaclass> Product_Detail { get; set; }
    }
}