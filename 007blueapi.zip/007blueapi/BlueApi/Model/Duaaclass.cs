﻿namespace BlueApi.Model
{
    public class Duaaclass
    {
       
        public string Firstname { get; set; }
        public string lastname { get; set; }
        public int id { get; set; }
       public  int contacts { get; set; }

    }
}
